//
//  serviceURL.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation

class ServiceUrl
{

    static let Base = "http://192.168.1.202:1992" //Local URL
    
    // HOME
    static let Home = Base + "/security/login"
}
