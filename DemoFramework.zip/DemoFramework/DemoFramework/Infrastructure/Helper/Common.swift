

import Foundation
import AVFoundation
import UIKit

class Common {

    func addshadow(View:UIView,shadowRadius:CGFloat? = 0,shadowColor:UIColor? = UIColor.darkGray,shadowOpacity:Float? = 0,borderWidth:CGFloat? = 0,borderColor:UIColor? = UIColor.clear,cornerRadius:CGFloat? = 0, shadowOffset:CGSize? = CGSize.zero, IsMaskToBounds:Bool = false) {
        
        View.layer.shadowRadius = shadowRadius!;
        View.layer.shadowColor = shadowColor?.cgColor;
        View.layer.shadowOffset = shadowOffset!
        View.layer.shadowOpacity = shadowOpacity!;
        View.layer.borderWidth = borderWidth!;
        View.layer.borderColor = borderColor?.cgColor;
        View.layer.cornerRadius = cornerRadius!;
        View.layer.masksToBounds = IsMaskToBounds
    }
    
    //MARK:- Set Image Tint Color
    func setImageTintColor(setImageView: UIImageView, TintColor: UIColor) -> UIImageView {
        setImageView.image = setImageView.image?.withRenderingMode(.alwaysTemplate)
        setImageView.tintColor = TintColor
        return setImageView;
    }
    
    //MARK:- Set Image Tint Color
    func setButtonImageTintColor(setButton: UIButton, ImageName: String, TintColor: UIColor) -> UIButton {
        
        let imgEdit = UIImage(named: ImageName)
        setButton.setImage(imgEdit?.withRenderingMode(.alwaysTemplate), for: .normal)        
        setButton.tintColor = TintColor
        return setButton
    }
    
    
    
}
