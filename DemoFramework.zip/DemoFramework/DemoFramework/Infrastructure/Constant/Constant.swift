//
//  Constant.swift
//  iOSProject
//
//  Created by Kaira NewMac on 12/8/16.
//  Copyright © 2016 Kaira NewMac. All rights reserved.
//

import Foundation
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate

struct AppConstant {

//    static let AppName = "Aakruti Creation" //Need Changes App name in LauchScreen Also
    static var AppName = "KCreation" //Need Changes App name in LauchScreen Also
    
    static let Rs = "\u{20B9}"
    
    static let Call = "\u{1F4DE}"
    
    static let APIKey = "SiteAppkey"

//    static let AppSiteSlug = "site1" //
    static let AppSiteSlug = "localhost"  // mytesting  //MyTesting
//    static let AppSiteSlug = "aakruticreation"  //Aakruti Creation
}

struct AppColor {

    //App Theme Status Bar
    static let Statusbar_Primary        = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.7)
    
    //App Theme
    static var AppTheme_Primary         = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 1.0)
    static var AppTheme_Secondary       = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    static let Dark_Pink_Secondary = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    static let Dark_Blue        = UIColor(red: 62/255, green: 75/255, blue: 94/255 , alpha :1)
    
    //General Light Color
    static let Light_Grey       = UIColor(red: 170/255, green: 170/255, blue: 170/255, alpha: 0.5)
    
    //General Dark Color
    static let Dark_Pink        = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 1.0)
    static let Dark_Green       =  UIColor(red: 68/255, green: 175/255, blue: 86/255 , alpha :1.0)
    
    static let Dark_Orange      =  UIColor(red: 209/255, green: 92/255, blue: 50/255, alpha: 1.0)
    static let Dark_Gray        = UIColor(red: 67/255, green: 65/255, blue: 73/255 , alpha :1)
    
    static let Red        = UIColor.red
}

struct FontStyle {
    static let Regular      = "-Regular"
    static let Bold         = "-Bold"
    static let Medium       = "-Medium"
    static let Light        = "-Light"
    static let SemiBold     = "-SemiBold"
    static let Italic       = "-Italic"
}

struct AppFont {
    //UIFont(name: "HelveticaNeue-Medium", size: 13.0)
    //Helvetica Neue Light 14.0
    static let HelveticaNeueMedium      = UIFont(name: "HelveticaNeue-Medium", size: 13.0)
    static let HelveticaNeue            = UIFont(name: "HelveticaNeue", size: 13.0)
    static let HelveticaNeueLight       = UIFont(name: "HelveticaNeue-Light", size: 14.0)
    
    static let HelveticaNeue_12         = UIFont(name: "HelveticaNeue", size: 12.0)    
    static let HelveticaNeue_14         = UIFont(name: "HelveticaNeue", size: 14.0)
    static let HelveticaNeueBold_14     = UIFont(name: "HelveticaNeue-Bold", size: 14.0)
}

struct AppMessage {

    static let SyncFail = "App is not synced properly. Please retry."
    static let RequestFail = "Network error, please try after some time."
    static let NoInternetConnection = "No internet connection found. Please restart app with internet connection."
    
    //Please login to add to Collection
    static let BeforeLogin              = "Please login to add to Wishlist."
    static let BeforeLoginWishList      = "Please login to open Wishlist."
    static let BeforeLoginToAddCart     = "Please login to add to Cart."
    static let BeforeLoginToBuy         = "Please login to Buy."
    
    static let UserNameEmpty = "User name required"
    
    static let mobileEmpty = "Mobile Number required"
    static let mobileError = "Invalid mobile number (i.e 0123456789)"
    
    static let emailEmpty = "Email required"
    static let emailError = "Invalid email address (i.e abc@mail.com)"
    
    static let descriptionEmpty = "Description required"
    
    
    static let mailAccountNotFound = "No email aoounnt found. Please provide your mail id with default mailbox."
    static let mailSave = "Rate us mail saved to draft"
    static let mailSent = "Mail sent successfully"
    static let mailError = "Please try again later, mail not sent"
    
    static let WhatsAppError = "Please, install whatsaap first"
    
    
    static let LoginTitle = "Discover & Shop Fashion"
    static let LoginTitleForWishList = "Login to add to a wishlist"
    static let LogoutMessage = "Are you sure you want to logout?"
    
    static let LoginSuccessfull         = "Login successfull"
    static let Logout                   = "Logout successfully"
    static let LoginTryAgain            = "Please try again!"
    
    static let AddToWishList            = "Added to Wishlist"
    static let RemoveFromWishList       = "Removed from Wishlist"
    
    static let NoProductFound       = "No Product Found"
}

struct UpdateOrderStatusMessage {
    static let OrderCancel  = "Order canceled successfully."
    static let OrderReceive = "Order received successfully."
    static let OrderNotReceive = "Order is not received yet."
}

struct ButtonTitle {
    
    //Button Title
    static let btnRetry = "Retry"
    static let btnOk = "OK"
    static let btnLogout = "Logout"
    static let btnCancel = "Cancel"
}

struct AlertTitle {
    
    //Error Title
    static let Error                        = "Error"
    static let Warning                      = "Warning"
    static let Success                      = "Success"
    
    static let RemoveProduct                = "Remove Product"
    static let RemoveProductSubTitle        = "Are you sure you want to remove this product from your cart?"
}

struct Unicode {
    
    static let UserName = "\u{f072}"
    static let Password = "\u{f023}"
}

// MARK: - Set RequireField Alert

struct RegularExpression {
    
    static let REGEX_EMAIL  = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
    static let REGEX_Mobile_NUMBER = "[0-9+]{10}"
    static let REGEX_ZipCode_NUMBER = "[0-9+]{6}"
}

struct TabbarTitle {
    
    static let Home = "Home"
    static let Category = "Category"
    static let Aboutus = "About Us"
    static let Notification = "Notification"
    static let WishList = "Wish List"
    static let VisiteStore = "Visite Store"
    static let Filter = "Filter"
    static let Profile = "Profile"
    //Order
    static let MyOrder = "My Order"
    static let OrderDteail = "Order Detail"
    static let MyCart = "My Cart"
}
//"Terms & Conditions"
struct NavigationBarTitle {
    static let TermsandCondition = "Terms & Conditions"
    static let Aboutus              = "About Us"
    static let ContactUs            = "Contact Us"
    static let AllProduct           = "All Product"
    static let AddAddress           = "Add Address"
    static let BuyNow               = "Payments"
}

struct TabbarImage {
    
    static let Home_unselect = "ic_tab_home_unselect"
    static let Category_unselect = "ic_tab_category_unselect"
    static let Notification_unselect = "ic_tab_notification_unselect"
    static let Wishlist_unselect = "ic_tab_wishlist_unselect"
    static let Aboutus_unselect = "ic_tab_aboutus_unselect"
    static let VisitStore_unselect = "ic_tab_visitstore_unselect"
    
    static let Home_Select = "ic_tab_home"
    static let Category_Select = "ic_tab_category"
    static let WishList_Select = "ic_tab_wishlist"
    static let Notification_Select = "ic_tab_notification"
    static let Aboutus_Select = "ic_tab_aboutus"
//    static let VisitStore_unselect = "ic_tab_visitstore_unselect"
}


struct SiteImageName {
    
    static let SectionBanner1           = "SectionBanner1"
    static let SectionBanner2           = "SectionBanner2"
    static let Gallery                  = "Gallery"
    
    static let Slider                   = "Slider"
    static let LogoImage                = "LogoImage"
    static let Slider1                  = "Slider1"
    static let Slider2                  = "Slider2"
    static let Slider3                  = "Slider3"
    static let Slider4                  = "Slider4"
    static let AboutusBanner            = "AboutusBanner"
    static let AboutusCompanylogo       = "AboutusCompanylogo"
    static let VisitorStoreBanner       = "VisitorStoreBanner"
    static let VisitorStoreLogo         = "VisitorStoreLogo"
    static let ContactUsBanner          = "ContactUsBanner"
    static let WishListBanner           = "WishListBanner"
    static let TermsCondition           = "TermsCondition"
    static let EnquiryBanner            = "EnquiryBanner"
    
}

struct SiteLabelsName {
    
    static let CurrencySymbol               = "CurrencySymbol"
    static let HomeLabel1                   = "HomeLabel1"
    static let HomeLabel2                   = "HomeLabel2"
    static let HomeLabel3                   = "HomeLabel3"
    static let HomeLabel4                   = "HomeLabel4"
}

struct AppImageName {
    
    static let Img_Placeholder = "ic_Test"
    static let Img_CategorySelect = "ic_CategorySelect"
    static let Img_LeftArrow = "LeftArrow"
    static let Img_RightArrow = "RightArrow"
    static let Img_WishListBanner = "ic_AppIconSplash"
    
    //FollowUS Button Image Name
    static let Img_Foolow_FB = "ic_Follow_FB"
    static let Img_Foolow_GP = "ic_Follow_GP"
    static let Img_Foolow_PT = "ic_Follow_PT"
    static let Img_Foolow_IG = "ic_Follow_IG"
    static let Img_Foolow_LD = "ic_Follow_LD"
    static let Img_Foolow_TW = "ic_Follow_TW"
    
    static let Img_WhatsApp = "ic_Whatsapp"
    static let Img_Address = "ic_Address"
    static let Img_Call = "ic_call"
    
    static let Img_AddToWishList = "ic_wishFill"
    
    static let Img_GuestUser = "ic_guestuser"
}

// MARK: Date Time Formate
struct DateTimeFormate {
    
    static let Formate_yyyyMMddTHHmmssZ = "yyyy-MM-dd\'T\'HH:mm:ss Z"
    
    static let Formate_yyyyMMddHHmmssZ = "yyyy-MM-dd\' \'HH:mm:ss Z"
    
    static let Formate_yyyyMMdd = "yyyy-MM-dd"
    
    static let Formate_yyyyMMddhhmmaa = "yyyy-MM-dd hh:mm aa"
    
    static let Formate_EEEdMMMyyyyathhmmaa = "EEE d MMM, yyyy 'at' hh:mm aa"
    
    static let Formate_EEEdMMMathhmma = "EEE d MMM 'at' hh:mm a"
    
    static let Formate_MMMdathhmma = "MMM d 'at' hh:mm a"
    
    static let Formate_ddMMMathhmma = "dd MMM' at' hh:mm a"
    
    static let Formate_hhmma = "hh:mm a"
    
    static let Formate_ddMMyyyyHHmmssZZZ = "dd-MM-yyyy HH:mm:ss ZZZ"
    
    static let Formate_ddMMMyyyyathhmma = "dd MMM, yyyy 'at' hh:mm a"
    
    static let Formate_yyyy = "yyyy"
    
    static let Formate_HHmmss = "HH:mm:ss"
    
    static let Formate_ddMMM = "dd MMM"
    
    static let Formate_hhmmaddMMMyyyy = "hh:mm a dd MMM, yyyy"
    
    static let Formate_ddMMMyyyy = "dd MMM, yyyy"
    
    static let Formate_ddMMMWithoutCommayyyy = "dd MMM yyyy"
}

struct ContactType {

    static let WhatsApp         = "WhatsApp"
    static let Mobile           = "Mobile"
    static let Landline         = "Landline"
}

struct WishListLabel {
    
    static let Items                = "0 Items"
    static let NoMyOrder            = "No Orders"
    static let NoMyCart             = "My Cart"
    static let MyWishList           = "My WishList"
    static let NoWishList           = "No WishList"
    static let FaceBook             = "FaceBook"
    static let GooglePlus           = "Google+"
    static let YourCollections      = "Your Collections"
    static let NoCollections        = "No Collections"
}

struct Sort {
    
    static let Asc                = "ASC"
    static let Desc                = "DESC"
}

struct SortExpresion {
    
    static let ViewCount        = "ViewCount"
    static let ProductID        = "ProductID"
    static let Price            = "Price"
    static let CreatedDate      = "CreatedDate"
}

//MARK: FeedBack Header title
struct FeedbackHeaderMessage {
    
    static let Comments                 = "Comments"
    static let CommentDescription       = "Write Comments here"
}

struct ValidationMessage {
    
    static let userNameEmpty                        = "Username required"
    static let passwordEmpty                        = "Password required"
    static let passwordInvalid                      = "Invalid passowd"
    
    static let emailEmpty                           = "Email required"
    static let mobileEmpty                          = "Mobile number required"
    
    static let emailError                           = "Invalid Email Address (i.e abcd@xyz.com)"
    static let firstNameError                       = "Invalid Firstname"
    static let lastNameError                        = "Invalid Lastname"
    static let passwordError                        = "Password must be at least 6 character"
    static let mobileError                          = "Mobile number must be 10 digits"
    static let mobileInvalid                        = "Invalid Mobile No."
    
    static let zipCodeError                          = "ZipCode must be 6 digits"
    
    static let SelectState                          = "Select State"
    
}

struct ProfileScreenList {
    
    static let ScreenString = "{\"Data\":[{\"ID\":0,\"Name\":\"Term & Condition\"},{\"ID\":1,\"Name\":\"About Us\"},{\"ID\":2,\"Name\":\"Contact Us\"},{\"ID\":3,\"Name\":\"Like on Facebook\"},{\"ID\":4,\"Name\":\"RateUs\"},{\"ID\":5,\"Name\":\"Share App\"},{\"ID\":6,\"Name\":\"Login\"}]}"
}
