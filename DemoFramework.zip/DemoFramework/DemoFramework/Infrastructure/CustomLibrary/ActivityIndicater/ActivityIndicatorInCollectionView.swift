//
//  ActivityIndicatorInTableView.swift
//  TTS
//
//  Created by KairaNewMac on 09/01/17.
//  Copyright © 2017 Kaira Software. All rights reserved.
//

import Foundation
import UIKit

class ActivityIndicatorInCollectionView{
    
    var container: UIView = UIView()
    var loadingView: UIView = UIView()
    var activityIndicator: UIActivityIndicatorView!
    
    //MARK: TableFooter Indicator
    func footerShow(collectionView:UICollectionView) -> UIView{
        
        if activityIndicator != nil && activityIndicator.isAnimating == true {
            hiddeActivityIndicator()
        }
        let noData = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(collectionView.bounds.size.width), height: CGFloat(30)))
        activityIndicator           = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
        activityIndicator.color     = UIColor.black
        noData.addSubview(activityIndicator)
        activityIndicator.center    = CGPoint(x: CGFloat(noData.frame.size.width / 2), y: CGFloat(noData.frame.size.height / 2))
        activityIndicator.startAnimating()
        noData.backgroundColor      = UIColor.clear
        noData.layer.cornerRadius   = 3
        return noData
    }
    
    func footerDismiss(collectionView:UICollectionView) ->UIView?{
        hiddeActivityIndicator()
        return nil
    }

    //MARK: Hidde Activity
    func hiddeActivityIndicator() {
        if((activityIndicator) != nil){
            activityIndicator.isHidden = true
            activityIndicator.removeFromSuperview()
            
        }
    }
    
   

}

