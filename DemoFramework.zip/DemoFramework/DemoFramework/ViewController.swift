//
//  ViewController.swift
//  DemoFramework
//
//  Created by Versatile Techno on 27/02/18.
//  Copyright © 2018 Versatile Techno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Hide Default Navigation Controller...!!!
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }

    @IBAction func btnClickedPush(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewControllerB") as! ViewControllerB
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

