

import Foundation

import ObjectMapper

class HomeDataProvider: NSObject {
 
    //get HOME screen
    func getHomeCall (objRequestModel : HomeRequestModel, IsLoader:Bool? = true, viewController:UIViewController? = nil, ServiceCallBack: @escaping (_ response:HomeGetModel<FeatureProductListModel>?, _ IsSuccess:Bool?)-> Void) {
        
        let JSONString = Mapper().toJSON(objRequestModel)
        ServiceRequestResponse.servicecall(IsLoader:IsLoader, url: ServiceUrl.Home, HttpMethod: .post, InputParameter: JSONString, viewController: viewController) { (result:String?, IsSuccess:Bool?) -> Void in
            
            if IsSuccess == true {
                let serviceResponse = Mapper<HomeGetModel<FeatureProductListModel>>().map(JSONString: result!)
                print(serviceResponse!)
                ServiceCallBack(serviceResponse!, true)
            } else {
                ServiceCallBack(nil, false)
            }
        }
    }
}
